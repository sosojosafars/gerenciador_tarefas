import { iniciarApp } from "./tarefaController.js";

iniciarApp();
